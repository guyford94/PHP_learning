<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Document</title>
</head>
<body>
    <?php 
    session_start(); 
    ?>
    <form action="index2.php"  method="POST">
    מה שמך?
    <input type="text" name="name">
    <br>
    <input type="submit">

</form>




</body>
</html>