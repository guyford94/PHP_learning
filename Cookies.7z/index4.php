<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Document</title>
</head>
<body>
    <?php
    if(!isset($_POST['jump'])){
   session_start();
    
  
   $_SESSION["Smok"] = $_POST["Smok"];
   setcookie("Smok",$_POST["Smok"], time() + 3600);
    }
    
?>


    <?php
    
        if(isset($_POST['jump'])){
            echo"היי " . $_COOKIE['name'] . "<br>";
            echo "אתה בן " . $_COOKIE['age'] . "<br>";
            echo " אתה " . $_COOKIE["Smok"] . " מעשן" . "<br>";
        }
        else{
    
        echo"היי " . $_SESSION['name'] . "<br>";
          echo "אתה בן " . $_SESSION['age'] . "<br>";
          echo " אתה " . $_SESSION["Smok"] . " מעשן" . "<br>";
        }
    ?>
</body>
</html>