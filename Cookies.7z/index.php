<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Document</title>
</head>
<body>

    <form action="index2.php"  method="POST">
    מה שמך?
    <input type="text" name="name">
    <br>
    <input type="submit">

</form>
<?php

if(isset($_COOKIE["name"]) && isset($_COOKIE["age"]) && isset($_COOKIE["Smok"])){
   echo(" <form action='index4.php'  method='POST'>");
   echo("<br>");
   echo("קפוץ לדף האחרון");
   echo("<br>");
   echo("<input type='submit' name='jump' value='jump'>");
   echo(" </form>");
    

}



?>



</body>
</html>