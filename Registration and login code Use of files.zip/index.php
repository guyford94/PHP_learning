<?php 

if(isset($_POST["singinSub"])){
    if($_POST["singinSub"]){
        $fp = fopen("password.txt", "r");
        while (!feof($fp)) 
        {
            fscanf($fp, "%s %s ", $userNameChek, $passwordChek);
            if($_POST["UserName"] == $userNameChek && $_POST["password"] == $passwordChek){
            die("Welcome");
            };
        };
        fclose ($fp);
        die("Incorrect username or password");
    };
};
if(isset($_POST["singupSub"])){
    if($_POST["singupSub"]){
        $userName = $_POST["NewUserName"];
        $password  = $_POST["Newpassword"];
        $fp = fopen("password.txt", "a");

        // writes a line
        $ktiva = $userName . " " . $password ;
        fwrite ($fp, $ktiva . "\n");
        //closes the file
        fclose ($fp);
        die("You have successfully registered");
    };


};




?>