var singIn = document.getElementById("SingInButton") 
var singUp = document.getElementById("SingUpButton")

singIn.addEventListener('click',function SingIN(){
    location.href = 'singin.html'
})

singUp.addEventListener('click',function SingIN(){
    location.href = 'singup.html'
})
