<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Document</title>
</head>
<body>

<?php

session_start();
if(!isset($_SESSION["gess"])){
    $_SESSION["gess"]=0;
   
    $rNum = rand(0,100);
 $_SESSION["rand"] = $rNum;
}
else{
    if($_SESSION["gess"] < 4){
    $_SESSION["gess"]=$_SESSION["gess"]+1;
    
    if($_POST["numberGess"] == $_SESSION["rand"] ){
        die("מזל טוב ניצחת המספר שנבחר הוא : " . $_SESSION["rand"] . "<br>");
    }
    if($_POST["numberGess"] < $_SESSION["rand"] . "<br>"){
        echo "המספר שנתת קטן מהמספר שנבחר ";
    }
    if($_POST["numberGess"] > $_SESSION["rand"] . "<br>"){
        echo "המספר שנתת גדול מהמספר שנבחר ";
    }
    }
    else{
        die("נגמרו לך הניסיונות הפסדת!!!!" . "המספר היה:  " . $_SESSION["rand"]);
    }

}

?>

<form action="index.php" method="post">
    <?php 
    if(isset($_SESSION["gess"])){
        echo "זה הניסיון ה" . $_SESSION["gess"] . " שלך" . "<br>";
        echo " נשארו לך " . 5- $_SESSION["gess"] . " ניסיונות " . "<br>";
    }
    ?>
    נא לבחור מספר
    <br>
    <input type="text" name="numberGess">
    <br>
    <input type="submit" name="sub">

</form>

    
</body>
</html>